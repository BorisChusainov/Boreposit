<!DOCTYPE html>
<html lang="de-AT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz</title>
    <style>
        body {
            text-align: center;
            font-size: 40px;
            font-family: 'Segoe UI';
            font-weight: bold;
            color: rgb(0, 187, 187);
        }
        a {
            color: rgb(187,0,187);
            text-decoration: underline transparent;
            transition: 0.2s;
        }
        a:hover {
            text-decoration: underline;
            transition: 0.2s;
        }
        p {
            margin-bottom: 1px;
            margin-top: 1px;
        }
        #red{color:rgb(187,0,0);}
        #green{color:rgb(0,187,0);}
    </style>
</head>
<body>
    <h1>Testergebnis</h1>
    <?php
        if (isset($_POST["in0"])) {
            //Gesamtpunktzahl mit Progress-Bar
            $gesamt = 0;
            for ($h=0;$h<14;$h++) {
                if ($_POST["in".$h] == $_POST["hid".$h]) {
                    $gesamt++;
                }
            }
            echo '<label for="ganz">Gesamtpunktzahl: '.$gesamt.'/14 Punkte</label><br><br>';
            //Einzeln beurteilen
            echo '<p>Aufgeteilt:</p><br>';
            for ($i=0;$i<14;$i++) {
                $k = $i + 1;
                if ($_POST["in".$i] == $_POST["hid".$i]) {
                    echo "<p id=\"green\">Frage ".$k." korrekt beantwortet</p><br>";
                } else if ($_POST["in".$i] != $_POST["hid".$i]) {
                    echo "<p id=\"red\">Frage ".$k." falsch beantwortet</p><br>";
                }
            }
            echo '<a href="index.html">Nochmal versuchen</a>';
        } else {
            echo "<p>Keine Antworten vorhanden</p>";
        }
    ?>
</body>
</html>